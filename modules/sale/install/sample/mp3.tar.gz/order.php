<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("");
?>&nbsp;<?$APPLICATION->IncludeFile("sale/sale_order/order_full.php", Array(
	"ORDER_PAGE"	=>	"order.php",
	"BASKET_PAGE"	=>	"basket.php",
	"PERSONAL_PAGE"	=>	"index.php",
	"ALLOW_PAY_FROM_ACCOUNT" => "N",
	)
);?><?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");
?>