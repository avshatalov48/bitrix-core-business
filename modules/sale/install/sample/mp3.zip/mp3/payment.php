<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
?>
<?
$APPLICATION->IncludeFile("sale/sale_order/payment.php");
?>